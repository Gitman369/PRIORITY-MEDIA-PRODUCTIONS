# Vis Screen Recorder — Web

The same app, as a static website — no build step, no Android Studio, no
compiler. Screen recording, AES-256 encrypted local storage, Google Drive
upload, and the AI Clips generator, all running in the browser.

## Before you share the launch link

Open `index.html` and change these two lines to use your actual live
domain instead of a relative path — social platforms (Twitter/X, Discord,
Slack, etc.) generally won't resolve relative image URLs in link
previews, so this needs to be absolute once you know where it's hosted:
```html
<meta property="og:image" content="icons/og-preview.png" />   <!-- change to https://yourdomain.com/icons/og-preview.png -->
<meta name="twitter:image" content="icons/og-preview.png" />  <!-- same -->
```
Everything else in the `<head>` (favicon, description) works as-is with
relative paths.

## What's new in this pass

- **Installable as a real app** (PWA) — a manifest + service worker mean
  browsers will offer "Install app" / "Add to Home Screen", and repeat
  visits load instantly from cache. The service worker deliberately only
  caches the app shell (HTML/CSS/JS/icons) — it never touches the
  ffmpeg.wasm CDN load or any API call, so it can't accidentally serve
  you a stale AI response or an old WASM build.
- **No more browser `alert()`/`confirm()` popups** — replaced with
  in-app toasts and a styled confirm dialog that actually matches the
  rest of the UI, including Escape-to-close and click-outside-to-close
  on both modals.
- **Global error resilience** — anything unhandled now surfaces as a
  visible toast instead of silently vanishing into the browser console
  where only a developer would ever see it.
- **In-browser preview player** — watch a recording back immediately
  after stopping, before deciding what to do with it; the library and
  AI Clips results now show real thumbnails and open a full preview
  modal on click instead of only offering blind download.

## Feature parity pass — ported from the Android build

Three features that existed on Android but hadn't made it to web yet:

- **3-2-1 countdown** before capture actually starts, once you've
  granted screen-share permission — gives you a moment to switch to
  whatever you meant to record before it's rolling.
- **Share button** (record result panel, and every library/clip preview)
  — uses the real Web Share API with file support where the browser
  offers it (mainly mobile Chrome and some recent desktop browsers),
  falling back to a download plus a clipboard-copied caption everywhere
  else, same growth-loop pattern as the Android app.
- **Manual trim** — pick your own start/end for *any* saved recording,
  not just AI-suggested clips. Same lossless stream-copy approach as
  AI Clips' cutting, exposed as its own tool via the preview modal's
  Trim button.

## Run it right now (fastest possible path)

You need a "secure context" for screen recording and encryption to work —
that means either `https://` or `localhost`. Opening `index.html` directly
as a `file://` URL will NOT work; browsers block both getDisplayMedia and
the Web Crypto API on plain file URLs.

**Fastest option — test locally in under 10 seconds:**
```bash
cd vis-screen-recorder-web
python3 -m http.server 8080
```
Then open `http://localhost:8080` in Chrome, Edge, or Firefox (desktop —
screen recording APIs don't exist on mobile browsers). That's it, fully
working, nothing to deploy.

No Python? Node works too: `npx serve .`

## Actually hosting it (so others can use it)

Any static host works since there's no server-side code at all:

- **Netlify (drag and drop):** go to app.netlify.com/drop, drag the
  `vis-screen-recorder-web` folder in. Live in seconds, HTTPS included.
- **GitHub Pages:** push this folder to a repo, enable Pages in repo
  settings pointing at the branch/root. Free, HTTPS included.
- **Vercel:** `npx vercel` from inside this folder, follow the prompts.

All three give you HTTPS automatically, which is required.

## First run

You'll be asked to set a passphrase — this is what encrypts your
recordings in this browser's storage (IndexedDB). There's no password
reset: forget it, and old recordings are unrecoverable ciphertext. That's
the actual tradeoff of real encryption, not a bug.

**Honest security note:** a browser has no hardware-backed keystore like
the Android app used. Your passphrase-derived key lives in this page's
JS memory for the session — real protection against someone browsing your
IndexedDB storage without the passphrase, but not equivalent to a native
OS secure enclave. Said plainly rather than implied to be identical.

## Connect Google Drive

1. Google Cloud Console → create/select a project.
2. **APIs & Services → Library** → enable the **Google Drive API**.
3. **OAuth consent screen** → External → add your own account as a test user → Testing mode is fine, no review needed.
4. **Credentials → Create Credentials → OAuth client ID** → type **Web application**.
5. Under **Authorized JavaScript origins**, add the exact URL you're hosting on (e.g. `http://localhost:8080` for local testing, or your real HTTPS domain once deployed). Every origin you use this from needs to be listed here — Google checks this strictly.
6. Copy the Client ID, paste it into Settings → Google Drive in the app.

## AI Clips setup

Same bring-your-own-key model as the Android app — this app has no AI of
its own. Add an OpenAI key, an NVIDIA Nemotron key (free tier at
build.nvidia.com), or point at any other OpenAI-compatible endpoint.

**If you hit a CORS error** (check your browser's console — a real CORS
block looks like "blocked by CORS policy", different from a 401/403 auth
error): that means the provider's API doesn't allow direct browser calls.
OpenAI has historically supported this pattern; I genuinely can't confirm
NVIDIA's NIM endpoint does the same without live network access to test
it myself. If it's blocked, the fix is a tiny proxy — here's the whole
thing as a Cloudflare Worker (free tier is plenty):

```js
// worker.js — deploy with `npx wrangler deploy`
export default {
  async fetch(request) {
    const url = new URL(request.url);
    const target = 'https://integrate.api.nvidia.com' + url.pathname + url.search;
    const proxied = await fetch(target, {
      method: request.method,
      headers: request.headers,
      body: request.method !== 'GET' ? await request.arrayBuffer() : undefined
    });
    const headers = new Headers(proxied.headers);
    headers.set('Access-Control-Allow-Origin', '*');
    return new Response(proxied.body, { status: proxied.status, headers });
  }
};
```
Then set your Base URL override in AI Settings to your Worker's URL
instead of NVIDIA's directly.

## Two hard boundaries (same as the Android app, same reasons)

- **"Import by link" only accepts direct video file URLs** — a Drive/
  Dropbox direct-download link to a file you own, not a YouTube/TikTok
  page URL. This app doesn't and won't attempt to extract video from
  platform pages; that breaks their Terms of Service.
- **The soundtrack feature attaches audio you supply** — your own
  voiceover or music you own/licensed, never a bundled catalog of
  trending songs.

## Known limitations, stated plainly

- **MP4 recording isn't guaranteed.** Browser support for direct MP4
  capture via MediaRecorder is inconsistent; this records WebM when MP4
  isn't available and can transcode to MP4 afterward via ffmpeg.wasm
  (slower, since it's a real re-encode, not a container remux).
- **ffmpeg.wasm loads from a CDN at runtime** (unpkg) — the very first
  trim/AI-clips action on each visit downloads roughly 30MB of WASM.
  After that it's cached by the browser. There's no offline-first path
  around this; it's the cost of doing real video encoding in a browser
  without a server.
- **No burnt-in captions** — same as the Android build, AI Clips
  generates a title/caption as metadata and share text, not text
  rendered onto the video frames.
- **Mobile browsers aren't supported** for the recording feature — screen
  capture APIs are a desktop-browser thing. AI Clips (working from an
  imported file rather than live recording) does work on mobile browsers
  that support the underlying APIs, for what it's worth.

## File map

```
index.html          — the whole app shell
css/styles.css       — matches the Android/extension brand identity
js/crypto.js         — passphrase-derived AES-256-GCM encryption
js/vault.js          — IndexedDB storage of encrypted recordings
js/recorder.js       — getDisplayMedia + MediaRecorder screen capture
js/ffmpegClient.js   — lazy-loaded ffmpeg.wasm for trim/mux/transcode
js/drive.js          — Google Identity Services OAuth + Drive upload
js/aiSettings.js     — your AI provider/key, stored locally only
js/aiClips.js        — Whisper transcription + clip-suggestion logic
js/branding.js       — name/color/logo customization
js/main.js           — wires all of the above to the UI
```
