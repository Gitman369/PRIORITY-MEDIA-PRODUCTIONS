// recorder.js — browser-native screen recording.
// Requires a secure context (https:// or localhost) — getDisplayMedia and
// the crypto in crypto.js both refuse to work otherwise, that's a browser
// platform rule, not something this code can work around.

let mediaRecorder = null;
let stream = null;
let chunks = [];
let startedAt = 0;
let pausedAccumMs = 0;
let pauseStartedAt = 0;

const QUALITY_MAP = {
  '2160': { width: 3840, height: 2160 },
  '1440': { width: 2560, height: 1440 },
  '1080': { width: 1920, height: 1080 },
  '720': { width: 1280, height: 720 }
};

export function isSupported() {
  return !!(navigator.mediaDevices && navigator.mediaDevices.getDisplayMedia && window.MediaRecorder);
}

function pickMimeType() {
  // Real MP4 recording support via MediaRecorder varies by browser/OS —
  // Chrome on some platforms supports it, most don't. We try, and fall
  // back to WebM, which every Chromium/Firefox browser records reliably.
  // (The AI Clips / trim pipeline can transcode WebM to MP4 with
  // ffmpeg.wasm if you specifically need an .mp4 file — see ffmpegClient.js.)
  const candidates = [
    'video/mp4;codecs=avc1',
    'video/mp4',
    'video/webm;codecs=vp9,opus',
    'video/webm'
  ];
  return candidates.find(t => MediaRecorder.isTypeSupported(t)) || 'video/webm';
}

let pendingMimeType = null;

/** Requests screen-share permission and sets up the recorder, but doesn't
 *  start writing yet — call beginCapture() after any countdown UI. */
export async function prepareRecording({ quality = '1080', includeMic = false, includeSystemAudio = true }) {
  if (!isSupported()) throw new Error('This browser doesn\'t support screen recording (needs getDisplayMedia + MediaRecorder).');

  const dims = QUALITY_MAP[quality] || QUALITY_MAP['1080'];
  stream = await navigator.mediaDevices.getDisplayMedia({
    video: { width: { ideal: dims.width }, height: { ideal: dims.height }, frameRate: { ideal: 30 } },
    audio: includeSystemAudio
  });

  if (includeMic) {
    try {
      const micStream = await navigator.mediaDevices.getUserMedia({ audio: true });
      micStream.getAudioTracks().forEach(t => stream.addTrack(t));
    } catch (e) {
      console.warn('Microphone unavailable:', e.message);
    }
  }

  const mimeType = pickMimeType();
  pendingMimeType = mimeType;
  chunks = [];
  pausedAccumMs = 0;

  mediaRecorder = new MediaRecorder(stream, {
    mimeType,
    videoBitsPerSecond: quality === '2160' ? 40_000_000 : quality === '1440' ? 20_000_000 : quality === '1080' ? 10_000_000 : 6_000_000
  });

  mediaRecorder.ondataavailable = e => { if (e.data.size > 0) chunks.push(e.data); };

  // If the user stops sharing via the browser's own "Stop sharing" UI
  // (rather than our Stop button), treat it the same as pressing Stop.
  const [videoTrack] = stream.getVideoTracks();
  const stopPromise = new Promise(resolve => {
    videoTrack.addEventListener('ended', () => resolve('browser-stopped'), { once: true });
  });

  return { mimeType, stopPromise };
}

/** Actually starts writing frames. Call after prepareRecording() (and any countdown). */
export function beginCapture() {
  if (!mediaRecorder) throw new Error('Call prepareRecording() first.');
  mediaRecorder.start(1000);
  startedAt = Date.now();
}

/** Cancels a prepared-but-not-yet-started recording (e.g. countdown was aborted). */
export function cancelPrepared() {
  if (stream) stream.getTracks().forEach(t => t.stop());
  mediaRecorder = null;
  stream = null;
  chunks = [];
}

export function pause() {
  if (mediaRecorder && mediaRecorder.state === 'recording') {
    mediaRecorder.pause();
    pauseStartedAt = Date.now();
  }
}

export function resume() {
  if (mediaRecorder && mediaRecorder.state === 'paused') {
    mediaRecorder.resume();
    pausedAccumMs += Date.now() - pauseStartedAt;
  }
}

export function getElapsedMs() {
  if (!startedAt) return 0;
  const livePause = mediaRecorder && mediaRecorder.state === 'paused' ? Date.now() - pauseStartedAt : 0;
  return Date.now() - startedAt - pausedAccumMs - livePause;
}

export function isRecording() {
  return !!mediaRecorder && mediaRecorder.state !== 'inactive';
}

export function isPaused() {
  return !!mediaRecorder && mediaRecorder.state === 'paused';
}

export function stopRecording() {
  return new Promise((resolve) => {
    if (!mediaRecorder) { resolve(null); return; }
    const mimeType = mediaRecorder.mimeType;
    mediaRecorder.onstop = () => {
      const blob = new Blob(chunks, { type: mimeType });
      stream.getTracks().forEach(t => t.stop());
      mediaRecorder = null;
      stream = null;
      startedAt = 0;
      resolve(blob);
    };
    if (mediaRecorder.state !== 'inactive') mediaRecorder.stop();
    else resolve(null);
  });
}
