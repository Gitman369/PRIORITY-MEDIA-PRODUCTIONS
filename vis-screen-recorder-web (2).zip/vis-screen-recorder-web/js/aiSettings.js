// aiSettings.js — your own AI API key, stored ONLY in this browser's
// localStorage. Never sent anywhere except the provider you configure.
//
// Real caveat, stated plainly: unlike the Android build (which uses
// EncryptedSharedPreferences backed by the Android Keystore), a browser
// has no equivalent secure enclave. localStorage here is plaintext on
// disk, readable by anything with access to this browser profile. That's
// a genuine security difference from the native app, not a detail to
// gloss over — don't use a key here you wouldn't be comfortable having
// sit in a browser profile.

export const PROVIDERS = {
  OPENAI: { label: 'ChatGPT (OpenAI)', defaultBaseUrl: 'https://api.openai.com/v1', defaultModel: 'gpt-4o-mini', supportsWhisper: true },
  NVIDIA_NEMOTRON: { label: 'NVIDIA Nemotron (NIM)', defaultBaseUrl: 'https://integrate.api.nvidia.com/v1', defaultModel: 'nvidia/nemotron-3-nano-30b-a3b', supportsWhisper: false },
  CUSTOM: { label: 'Custom OpenAI-compatible', defaultBaseUrl: '', defaultModel: '', supportsWhisper: false }
};

const KEY_PROVIDER = 'vis_ai_provider';
const KEY_API_KEY = 'vis_ai_api_key';
const KEY_BASE_URL = 'vis_ai_base_url';
const KEY_MODEL = 'vis_ai_model';

export function getProvider() {
  return localStorage.getItem(KEY_PROVIDER) || 'OPENAI';
}

export function getApiKey() {
  return localStorage.getItem(KEY_API_KEY) || '';
}

export function getBaseUrl() {
  const custom = localStorage.getItem(KEY_BASE_URL);
  if (custom) return custom;
  return PROVIDERS[getProvider()]?.defaultBaseUrl || '';
}

export function getModel() {
  const custom = localStorage.getItem(KEY_MODEL);
  if (custom) return custom;
  return PROVIDERS[getProvider()]?.defaultModel || '';
}

export function isConfigured() {
  return getApiKey().length > 0;
}

export function providerSupportsWhisper() {
  return PROVIDERS[getProvider()]?.supportsWhisper ?? false;
}

export function save({ provider, apiKey, baseUrl, model }) {
  localStorage.setItem(KEY_PROVIDER, provider);
  localStorage.setItem(KEY_API_KEY, apiKey);
  if (baseUrl) localStorage.setItem(KEY_BASE_URL, baseUrl); else localStorage.removeItem(KEY_BASE_URL);
  if (model) localStorage.setItem(KEY_MODEL, model); else localStorage.removeItem(KEY_MODEL);
}

export function clear() {
  [KEY_PROVIDER, KEY_API_KEY, KEY_BASE_URL, KEY_MODEL].forEach(k => localStorage.removeItem(k));
}
