// ffmpegClient.js — lazy-loaded ffmpeg.wasm for trim/transcode/audio-mux.
//
// Deliberately uses the single-threaded @ffmpeg/core build, not core-mt.
// The multi-threaded build needs COOP/COEP response headers, which most
// simple static hosts (GitHub Pages, a plain Netlify drop, S3, etc.) don't
// set by default — using it would mean this silently breaks on the exact
// "just host it" setups this project is for. Single-threaded is slower but
// works everywhere without server config.
//
// Loaded from a CDN (unpkg) at runtime, same pattern as any other web
// library — nothing here runs at build time. Version pinned; ffmpeg.wasm
// does occasionally change its API shape between majors, so if loading
// fails, check the pinned version against https://github.com/ffmpegwasm/ffmpeg.wasm.

const FFMPEG_VERSION = '0.12.10';
const CORE_VERSION = '0.12.6';

let ffmpegInstance = null;
let loadingPromise = null;

async function loadFfmpeg(onProgress) {
  if (ffmpegInstance) return ffmpegInstance;
  if (loadingPromise) return loadingPromise;

  loadingPromise = (async () => {
    const { FFmpeg } = await import(`https://unpkg.com/@ffmpeg/ffmpeg@${FFMPEG_VERSION}/dist/esm/index.js`);
    const { toBlobURL } = await import(`https://unpkg.com/@ffmpeg/util@0.12.1/dist/esm/index.js`);

    const ffmpeg = new FFmpeg();
    if (onProgress) {
      ffmpeg.on('progress', ({ progress }) => onProgress(Math.round(progress * 100)));
    }

    const coreBase = `https://unpkg.com/@ffmpeg/core@${CORE_VERSION}/dist/umd`;
    await ffmpeg.load({
      coreURL: await toBlobURL(`${coreBase}/ffmpeg-core.js`, 'text/javascript'),
      wasmURL: await toBlobURL(`${coreBase}/ffmpeg-core.wasm`, 'application/wasm')
    });

    ffmpegInstance = ffmpeg;
    return ffmpeg;
  })();

  return loadingPromise;
}

async function blobToFfmpegFile(ffmpeg, blob, filename) {
  const { fetchFile } = await import(`https://unpkg.com/@ffmpeg/util@0.12.1/dist/esm/index.js`);
  await ffmpeg.writeFile(filename, await fetchFile(blob));
}

/** Cuts [startSec, endSec] out of the video. Uses stream copy (-c copy) —
 *  fast and lossless, but like the Android trimmer, the actual cut point
 *  snaps to the nearest keyframe rather than being frame-exact. */
export async function trimVideo(blob, startSec, endSec, { onProgress } = {}) {
  const ffmpeg = await loadFfmpeg(onProgress);
  const inputName = 'input' + guessExtension(blob.type);
  const outputName = 'output.mp4';

  await blobToFfmpegFile(ffmpeg, blob, inputName);
  await ffmpeg.exec([
    '-ss', String(startSec), '-to', String(endSec),
    '-i', inputName, '-c', 'copy', outputName
  ]);
  const data = await ffmpeg.readFile(outputName);
  await ffmpeg.deleteFile(inputName);
  await ffmpeg.deleteFile(outputName);
  return new Blob([data.buffer], { type: 'video/mp4' });
}

/** Replaces the video's audio track with a user-supplied audio file,
 *  trimmed/looped isn't attempted — audio simply ends when it ends. */
export async function applySoundtrack(videoBlob, audioBlob, { onProgress } = {}) {
  const ffmpeg = await loadFfmpeg(onProgress);
  const videoName = 'video' + guessExtension(videoBlob.type);
  const audioName = 'audio' + guessExtension(audioBlob.type);
  const outputName = 'output.mp4';

  await blobToFfmpegFile(ffmpeg, videoBlob, videoName);
  await blobToFfmpegFile(ffmpeg, audioBlob, audioName);
  await ffmpeg.exec([
    '-i', videoName, '-i', audioName,
    '-map', '0:v:0', '-map', '1:a:0',
    '-c:v', 'copy', '-c:a', 'aac', '-shortest',
    outputName
  ]);
  const data = await ffmpeg.readFile(outputName);
  await ffmpeg.deleteFile(videoName);
  await ffmpeg.deleteFile(audioName);
  await ffmpeg.deleteFile(outputName);
  return new Blob([data.buffer], { type: 'video/mp4' });
}

/** Transcodes any recorded format (typically WebM) into a real MP4 —
 *  used when the browser couldn't record MP4 directly (see recorder.js). */
export async function transcodeToMp4(blob, { onProgress } = {}) {
  const ffmpeg = await loadFfmpeg(onProgress);
  const inputName = 'input' + guessExtension(blob.type);
  const outputName = 'output.mp4';

  await blobToFfmpegFile(ffmpeg, blob, inputName);
  await ffmpeg.exec(['-i', inputName, '-c:v', 'libx264', '-preset', 'veryfast', '-c:a', 'aac', outputName]);
  const data = await ffmpeg.readFile(outputName);
  await ffmpeg.deleteFile(inputName);
  await ffmpeg.deleteFile(outputName);
  return new Blob([data.buffer], { type: 'video/mp4' });
}

/** Extracts just the audio track — used to keep Whisper uploads small. */
export async function extractAudio(blob, { onProgress } = {}) {
  const ffmpeg = await loadFfmpeg(onProgress);
  const inputName = 'input' + guessExtension(blob.type);
  const outputName = 'audio.m4a';

  await blobToFfmpegFile(ffmpeg, blob, inputName);
  await ffmpeg.exec(['-i', inputName, '-vn', '-c:a', 'aac', '-b:a', '96k', outputName]);
  const data = await ffmpeg.readFile(outputName);
  await ffmpeg.deleteFile(inputName);
  await ffmpeg.deleteFile(outputName);
  return new Blob([data.buffer], { type: 'audio/mp4' });
}

function guessExtension(mimeType) {
  if (mimeType.includes('webm')) return '.webm';
  if (mimeType.includes('mp4')) return '.mp4';
  return '.bin';
}
