// toast.js — small, consistent in-app notifications. Used instead of
// alert()/confirm() wherever a blocking native dialog isn't actually
// necessary — alert() looks and feels like it belongs to a different,
// much older app than the rest of this UI.

let container = null;

function ensureContainer() {
  if (container) return container;
  container = document.createElement('div');
  container.className = 'toast-container';
  container.setAttribute('aria-live', 'polite');
  document.body.appendChild(container);
  return container;
}

/**
 * @param {string} message
 * @param {'info'|'success'|'error'} type
 */
export function toast(message, type = 'info') {
  const el = document.createElement('div');
  el.className = `toast toast-${type}`;
  el.textContent = message;
  ensureContainer().appendChild(el);

  requestAnimationFrame(() => el.classList.add('toast-visible'));

  const remove = () => {
    el.classList.remove('toast-visible');
    setTimeout(() => el.remove(), 250);
  };
  el.addEventListener('click', remove);
  setTimeout(remove, 4200);
}

/** Simple in-app confirm replacement — resolves true/false. Still a
 *  modal (some decisions genuinely should block), but styled consistently
 *  instead of a native browser confirm() dialog. */
export function confirmDialog(message) {
  return new Promise((resolve) => {
    const overlay = document.createElement('div');
    overlay.className = 'confirm-overlay';
    overlay.innerHTML = `
      <div class="confirm-card">
        <p>${message}</p>
        <div class="confirm-actions">
          <button class="btn btn-ghost" data-choice="cancel">Cancel</button>
          <button class="btn btn-danger" data-choice="ok">Delete</button>
        </div>
      </div>`;
    document.body.appendChild(overlay);
    requestAnimationFrame(() => overlay.classList.add('confirm-visible'));

    function cleanup(result) {
      overlay.classList.remove('confirm-visible');
      setTimeout(() => overlay.remove(), 200);
      document.removeEventListener('keydown', onKey);
      resolve(result);
    }
    function onKey(e) {
      if (e.key === 'Escape') cleanup(false);
    }
    overlay.addEventListener('click', (e) => {
      const choice = e.target.dataset.choice;
      if (choice === 'ok') cleanup(true);
      else if (choice === 'cancel' || e.target === overlay) cleanup(false);
    });
    document.addEventListener('keydown', onKey);
  });
}
