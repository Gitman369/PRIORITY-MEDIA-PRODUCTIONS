// drive.js — Google Drive upload using Google Identity Services (GIS).
//
// Setup required before this works — see README "Connect Google Drive".
// Uses the drive.file scope only: this app can see/manage only the files
// IT creates, never your existing Drive contents.

const DRIVE_SCOPE = 'https://www.googleapis.com/auth/drive.file';
let tokenClient = null;
let accessToken = null;

function getClientId() {
  return localStorage.getItem('vis_google_client_id') || '';
}

export function setClientId(clientId) {
  localStorage.setItem('vis_google_client_id', clientId);
}

export function hasClientId() {
  return getClientId().length > 0;
}

function ensureGisLoaded() {
  return new Promise((resolve, reject) => {
    if (window.google && window.google.accounts && window.google.accounts.oauth2) {
      resolve();
      return;
    }
    const script = document.createElement('script');
    script.src = 'https://accounts.google.com/gsi/client';
    script.onload = () => resolve();
    script.onerror = () => reject(new Error('Could not load Google Identity Services — check your connection.'));
    document.head.appendChild(script);
  });
}

/** Opens the Google sign-in popup and resolves once we have an access token. */
export async function signIn() {
  const clientId = getClientId();
  if (!clientId) throw new Error('Add your Google OAuth Client ID in settings first.');

  await ensureGisLoaded();

  return new Promise((resolve, reject) => {
    tokenClient = google.accounts.oauth2.initTokenClient({
      client_id: clientId,
      scope: DRIVE_SCOPE,
      callback: (response) => {
        if (response.error) {
          reject(new Error(response.error));
          return;
        }
        accessToken = response.access_token;
        resolve(accessToken);
      }
    });
    tokenClient.requestAccessToken();
  });
}

export function isSignedIn() {
  return accessToken !== null;
}

export function signOut() {
  if (accessToken && window.google) {
    google.accounts.oauth2.revoke(accessToken, () => {});
  }
  accessToken = null;
}

/** Uploads a Blob to Drive, returns the resulting file's webViewLink. */
export async function uploadToDrive(blob, filename) {
  if (!accessToken) await signIn();

  const metadata = { name: filename, mimeType: blob.type || 'video/mp4' };
  const form = new FormData();
  form.append('metadata', new Blob([JSON.stringify(metadata)], { type: 'application/json' }));
  form.append('file', blob);

  const response = await fetch(
    'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,webViewLink',
    { method: 'POST', headers: { Authorization: `Bearer ${accessToken}` }, body: form }
  );

  if (!response.ok) {
    if (response.status === 401) {
      // Token expired — clear it so the next attempt re-prompts sign-in.
      accessToken = null;
    }
    const text = await response.text();
    throw new Error(`Drive upload failed: ${response.status} ${text.slice(0, 200)}`);
  }

  const data = await response.json();
  return data.webViewLink;
}
