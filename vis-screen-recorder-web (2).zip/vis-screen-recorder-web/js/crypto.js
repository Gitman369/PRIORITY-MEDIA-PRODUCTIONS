// crypto.js — AES-256-GCM encryption backed by a passphrase you set.
//
// Honest difference from the Android build: there's no hardware Keystore
// in a browser. The real protection here comes from your passphrase —
// without it, the ciphertext sitting in IndexedDB is unreadable, but if
// someone has your unlocked browser session (and you've entered your
// passphrase this session), the derived key lives in memory like any
// other in-page JS value. That's the actual security model of a web app;
// stated plainly rather than implied to be equivalent to a native OS
// keystore, because it isn't.

const PBKDF2_ITERATIONS = 250_000;
const SALT_STORAGE_KEY = 'vis_vault_salt';

let cachedKey = null; // non-extractable CryptoKey, held only for this page session

function bufToBase64(buf) {
  const bytes = new Uint8Array(buf);
  let binary = '';
  for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary);
}

function base64ToBuf(base64) {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes.buffer;
}

function getOrCreateSalt() {
  let saltB64 = localStorage.getItem(SALT_STORAGE_KEY);
  if (!saltB64) {
    const salt = crypto.getRandomValues(new Uint8Array(16));
    saltB64 = bufToBase64(salt.buffer);
    localStorage.setItem(SALT_STORAGE_KEY, saltB64);
  }
  return new Uint8Array(base64ToBuf(saltB64));
}

export function hasVault() {
  return localStorage.getItem(SALT_STORAGE_KEY) !== null;
}

export function isUnlocked() {
  return cachedKey !== null;
}

export function lock() {
  cachedKey = null;
}

/** Derives (or re-derives) the AES key from a passphrase. Doesn't verify
 *  correctness by itself — verifyPassphrase() does that against a canary. */
async function deriveKey(passphrase) {
  const salt = getOrCreateSalt();
  const baseKey = await crypto.subtle.importKey(
    'raw', new TextEncoder().encode(passphrase), 'PBKDF2', false, ['deriveKey']
  );
  return crypto.subtle.deriveKey(
    { name: 'PBKDF2', salt, iterations: PBKDF2_ITERATIONS, hash: 'SHA-256' },
    baseKey,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt']
  );
}

const CANARY_STORAGE_KEY = 'vis_vault_canary';
const CANARY_PLAINTEXT = 'vis-screen-recorder-unlock-check';

/** Call once when the user first sets a passphrase. */
export async function initializeVault(passphrase) {
  cachedKey = await deriveKey(passphrase);
  const canary = await encryptString(CANARY_PLAINTEXT);
  localStorage.setItem(CANARY_STORAGE_KEY, JSON.stringify(canary));
}

/** Call on every subsequent unlock attempt. Returns true/false — doesn't throw. */
export async function tryUnlock(passphrase) {
  try {
    const key = await deriveKey(passphrase);
    const canaryRaw = localStorage.getItem(CANARY_STORAGE_KEY);
    if (!canaryRaw) return false;
    const { ivB64, dataB64 } = JSON.parse(canaryRaw);
    const plain = await decryptWithKey(key, ivB64, dataB64);
    if (plain !== CANARY_PLAINTEXT) return false;
    cachedKey = key;
    return true;
  } catch (e) {
    return false;
  }
}

async function decryptWithKey(key, ivB64, dataB64) {
  const iv = new Uint8Array(base64ToBuf(ivB64));
  const data = base64ToBuf(dataB64);
  const plainBuf = await crypto.subtle.decrypt({ name: 'AES-GCM', iv }, key, data);
  return new TextDecoder().decode(plainBuf);
}

async function encryptString(text) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const data = await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv }, cachedKey, new TextEncoder().encode(text)
  );
  return { ivB64: bufToBase64(iv.buffer), dataB64: bufToBase64(data) };
}

/** Encrypts a Blob (a recording) — returns {iv, data} as raw binary, ready for IndexedDB.
 *  Deliberately NOT base64 here: IndexedDB stores ArrayBuffer/Uint8Array natively, and
 *  base64-encoding a multi-hundred-MB video would waste ~33% space and double the
 *  memory churn for no benefit — base64 is only used above for the small localStorage values. */
export async function encryptBlob(blob) {
  if (!cachedKey) throw new Error('Vault is locked.');
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const buf = await blob.arrayBuffer();
  const data = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, cachedKey, buf);
  return { iv, data }; // iv: Uint8Array, data: ArrayBuffer
}

/** Decrypts back into a Blob of the given mime type. */
export async function decryptToBlob(iv, data, mimeType = 'video/mp4') {
  if (!cachedKey) throw new Error('Vault is locked.');
  const plainBuf = await crypto.subtle.decrypt({ name: 'AES-GCM', iv }, cachedKey, data);
  return new Blob([plainBuf], { type: mimeType });
}
