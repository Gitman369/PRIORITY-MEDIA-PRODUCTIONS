// vault.js — IndexedDB storage for encrypted recordings/clips.
// Mirrors the Android app's vault: nothing here is ever plaintext at rest.

import { encryptBlob, decryptToBlob } from './crypto.js';

const DB_NAME = 'vis_screen_recorder';
const DB_VERSION = 1;
const STORE = 'vault_entries';

function openDb() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE)) {
        const store = db.createObjectStore(STORE, { keyPath: 'id' });
        store.createIndex('createdAt', 'createdAt');
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

/** Encrypts and stores a recording Blob, with an optional thumbnail (also
 *  encrypted — a plaintext thumbnail would quietly break the "nothing at
 *  rest is readable" promise the rest of this app makes). Returns the id. */
export async function saveRecording(blob, { name, mimeType, theme = null, caption = null, thumbnailBlob = null }) {
  const { iv, data } = await encryptBlob(blob);
  let thumbIv = null, thumbData = null;
  if (thumbnailBlob) {
    const encThumb = await encryptBlob(thumbnailBlob);
    thumbIv = encThumb.iv;
    thumbData = encThumb.data;
  }

  const db = await openDb();
  const id = `rec-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  const entry = {
    id, name, mimeType, theme, caption,
    sizeBytes: blob.size,
    createdAt: Date.now(),
    iv, data, thumbIv, thumbData
  };
  await new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readwrite');
    tx.objectStore(STORE).put(entry);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
  return id;
}

/** Lists all entries WITHOUT decrypting the recording itself — just
 *  metadata plus a decrypted thumbnail (cheap, since the vault is only
 *  ever browsable while already unlocked for the session anyway). */
export async function listRecordings() {
  const db = await openDb();
  const raw = await new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readonly');
    const req = tx.objectStore(STORE).getAll();
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });

  const entries = await Promise.all(raw.map(async (e) => {
    let thumbnailUrl = null;
    if (e.thumbIv && e.thumbData) {
      try {
        const thumbBlob = await decryptToBlob(e.thumbIv, e.thumbData, 'image/jpeg');
        thumbnailUrl = URL.createObjectURL(thumbBlob);
      } catch (err) { /* thumbnail is optional — fine if it can't decrypt */ }
    }
    return {
      id: e.id, name: e.name, mimeType: e.mimeType, theme: e.theme, caption: e.caption,
      sizeBytes: e.sizeBytes, createdAt: e.createdAt, thumbnailUrl
    };
  }));

  return entries.sort((a, b) => b.createdAt - a.createdAt);
}

/** Decrypts one entry back into a usable Blob. */
export async function loadRecording(id) {
  const db = await openDb();
  const entry = await new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readonly');
    const req = tx.objectStore(STORE).get(id);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
  if (!entry) throw new Error('Recording not found.');
  const blob = await decryptToBlob(entry.iv, entry.data, entry.mimeType);
  return { blob, name: entry.name, theme: entry.theme, caption: entry.caption };
}

export async function deleteRecording(id) {
  const db = await openDb();
  await new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readwrite');
    tx.objectStore(STORE).delete(id);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function totalSizeBytes() {
  const entries = await listRecordings();
  return entries.reduce((sum, e) => sum + (e.sizeBytes || 0), 0);
}
