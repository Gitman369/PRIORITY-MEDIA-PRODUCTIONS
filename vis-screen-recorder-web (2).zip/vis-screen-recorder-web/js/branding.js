// branding.js — in-app name/color/logo customization, persisted locally.

const KEY_NAME = 'vis_brand_name';
const KEY_ACCENT = 'vis_brand_accent';
const KEY_LOGO = 'vis_brand_logo'; // data URL

export function getName() {
  return localStorage.getItem(KEY_NAME) || 'Vis Screen Recorder';
}

export function getAccent() {
  return localStorage.getItem(KEY_ACCENT) || '#FF4D4F';
}

export function getLogo() {
  return localStorage.getItem(KEY_LOGO) || null;
}

export function save({ name, accent, logoDataUrl }) {
  if (name) localStorage.setItem(KEY_NAME, name);
  if (accent) localStorage.setItem(KEY_ACCENT, accent);
  if (logoDataUrl) localStorage.setItem(KEY_LOGO, logoDataUrl);
}

export function reset() {
  [KEY_NAME, KEY_ACCENT, KEY_LOGO].forEach(k => localStorage.removeItem(k));
}

export function applyToDocument() {
  document.documentElement.style.setProperty('--accent', getAccent());
  document.title = getName();
}
