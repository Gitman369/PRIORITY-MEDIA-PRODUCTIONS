// aiClips.js — asks your configured AI which moments make good clips.
//
// IMPORTANT CORS CAVEAT, stated honestly because I can't verify this from
// a sandbox with no network access: OpenAI's API has historically allowed
// direct browser fetch() calls (no CORS block) for exactly this
// bring-your-own-key client-side pattern. Whether NVIDIA's NIM endpoint
// (integrate.api.nvidia.com) does the same is something I genuinely
// couldn't confirm without live network access — if Nemotron calls fail
// with a CORS error in your browser's console (not a 401/403, an actual
// blocked-by-CORS-policy error), that means their endpoint doesn't allow
// direct browser calls, and you'd need a tiny server-side proxy to relay
// the request. A minimal proxy snippet for exactly this case is in the
// README under "If you hit a CORS error."

import * as AiSettings from './aiSettings.js';

export const THEMES = [
  { id: 'bold', label: 'Bold & Punchy', tone: 'punchy, high-energy, short exclamatory phrases, hype-trailer feel', accent: '#FF4D4F' },
  { id: 'clean', label: 'Clean & Minimal', tone: 'calm, confident, understated, no hype language', accent: '#35C98F' },
  { id: 'educational', label: 'Educational', tone: "clear and instructive, frames it as 'here's what you'll learn'", accent: '#4D9FFF' },
  { id: 'motivational', label: 'Motivational', tone: 'inspiring, second-person, encouraging, builds toward a call to action', accent: '#FFB84D' },
  { id: 'storytelling', label: 'Storytelling', tone: 'narrative hook, creates curiosity, teases without giving it away', accent: '#C084FC' }
];

/** Transcribes audio via OpenAI Whisper. Only meaningful when the OpenAI provider is active. */
export async function transcribe(audioBlob) {
  const apiKey = AiSettings.getApiKey();
  const baseUrl = AiSettings.getBaseUrl();

  if (audioBlob.size > 25 * 1024 * 1024) {
    throw new Error("Audio is over Whisper's 25MB upload limit — try a shorter recording.");
  }

  const form = new FormData();
  form.append('file', audioBlob, 'audio.m4a');
  form.append('model', 'whisper-1');
  form.append('response_format', 'verbose_json');

  const response = await fetch(`${baseUrl}/audio/transcriptions`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${apiKey}` },
    body: form
  });

  if (!response.ok) {
    throw new Error(`Transcription failed: ${response.status} ${await response.text()}`);
  }

  const json = await response.json();
  if (Array.isArray(json.segments)) {
    return json.segments.map(s => ({ start: s.start, end: s.end, text: (s.text || '').trim() }));
  }
  return json.text ? [{ start: 0, end: 0, text: json.text }] : [];
}

/** Asks the configured chat model to pick clip-worthy moments. Falls back
 *  to evenly-spaced segments if there's no transcript or the call fails. */
export async function suggestClips({ theme, transcript, durationSec, clipCount = 5, clipLengthSec = 30 }) {
  if (!transcript || transcript.length === 0) {
    return evenlySpacedFallback(theme, durationSec, clipCount, clipLengthSec);
  }

  const apiKey = AiSettings.getApiKey();
  const baseUrl = AiSettings.getBaseUrl();
  const model = AiSettings.getModel();

  const transcriptText = transcript
    .map(s => `[${Math.round(s.start)}s-${Math.round(s.end)}s] ${s.text}`)
    .join('\n')
    .slice(0, 12000);

  const systemPrompt = `You select the best short-clip moments from a screen-recording transcript.
Tone for titles/captions: ${theme.tone}
Respond with ONLY valid JSON, no markdown fences, no commentary, in this exact shape:
{"clips":[{"start":12.5,"end":42.0,"title":"...","caption":"..."}]}
Pick up to ${clipCount} non-overlapping segments, each roughly ${clipLengthSec} seconds,
that would work as standalone short-form clips. start/end are in seconds and must fall
within the transcript's time range.`;

  try {
    const response = await fetch(`${baseUrl}/chat/completions`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model,
        temperature: 0.4,
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: `Transcript:\n${transcriptText}` }
        ]
      })
    });

    if (!response.ok) throw new Error(`AI request failed: ${response.status} ${await response.text()}`);

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content;
    if (!content) throw new Error('AI response had no content.');

    const cleaned = content.trim().replace(/^```json/, '').replace(/^```/, '').replace(/```$/, '').trim();
    const parsed = JSON.parse(cleaned);
    const clips = (parsed.clips || []).map((c, i) => ({
      start: c.start, end: c.end,
      title: c.title || `Clip ${i + 1}`,
      caption: c.caption || ''
    }));

    return clips.length > 0 ? clips.slice(0, clipCount) : evenlySpacedFallback(theme, durationSec, clipCount, clipLengthSec);
  } catch (e) {
    console.warn('AI clip suggestion failed, using fallback:', e.message);
    return evenlySpacedFallback(theme, durationSec, clipCount, clipLengthSec);
  }
}

export function evenlySpacedFallback(theme, durationSec, clipCount, clipLengthSec = 30) {
  if (!durationSec || durationSec <= 0) return [];
  const actualCount = Math.min(clipCount, Math.max(1, Math.floor(durationSec / clipLengthSec)));
  const spacing = durationSec / actualCount;
  return Array.from({ length: actualCount }, (_, i) => {
    const start = i * spacing;
    const end = Math.min(start + clipLengthSec, durationSec);
    return { start, end, title: `${theme.label} Clip ${i + 1}`, caption: '' };
  });
}
