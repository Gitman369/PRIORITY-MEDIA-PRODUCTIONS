// main.js — wires the UI to every module. Vanilla JS, no framework/build
// step, so this can just be hosted as static files.

import * as VaultCrypto from './crypto.js';
import * as Vault from './vault.js';
import * as Recorder from './recorder.js';
import * as Ffmpeg from './ffmpegClient.js';
import * as Drive from './drive.js';
import * as AiSettings from './aiSettings.js';
import * as AiClips from './aiClips.js';
import * as Branding from './branding.js';
import { toast, confirmDialog } from './toast.js';

const $ = (id) => document.getElementById(id);

// ---------------------------------------------------------------------
// Vault unlock gate
// ---------------------------------------------------------------------

function initUnlockGate() {
  const overlay = $('unlockOverlay');
  const subtitle = $('unlockSubtitle');
  const btn = $('unlockBtn');
  const input = $('passphraseInput');
  const error = $('unlockError');
  const firstTime = !VaultCrypto.hasVault();

  subtitle.textContent = firstTime
    ? 'Set a passphrase to encrypt your recordings on this device.'
    : 'Enter your passphrase to unlock your recordings.';
  btn.textContent = firstTime ? 'Create vault' : 'Unlock';

  async function attempt() {
    const value = input.value;
    if (!value || value.length < 4) {
      error.textContent = 'Passphrase must be at least 4 characters.';
      return;
    }
    error.textContent = '';
    btn.disabled = true;
    try {
      if (firstTime) {
        await VaultCrypto.initializeVault(value);
        overlay.classList.add('hidden');
        boot();
      } else {
        const ok = await VaultCrypto.tryUnlock(value);
        if (ok) {
          overlay.classList.add('hidden');
          boot();
        } else {
          error.textContent = 'Wrong passphrase.';
        }
      }
    } catch (e) {
      error.textContent = e.message || 'Something went wrong.';
    } finally {
      btn.disabled = false;
    }
  }

  btn.addEventListener('click', attempt);
  input.addEventListener('keydown', (e) => { if (e.key === 'Enter') attempt(); });
  input.focus();
}

// ---------------------------------------------------------------------
// Boot — runs once the vault is unlocked
// ---------------------------------------------------------------------

function boot() {
  $('app').classList.remove('hidden');
  applyBranding();
  initTabs();
  initRecordView();
  initLibraryView();
  initClipsView();
  initSettingsView();
  initAiSettingsModal();
  refreshLibrary();
  updateVaultStatus();
}

function applyBranding() {
  Branding.applyToDocument();
  $('brandName').textContent = Branding.getName();
  $('unlockBrandName').textContent = Branding.getName();
  const logo = Branding.getLogo();
  if (logo) $('brandLogo').src = logo;
  else $('brandLogo').style.background = Branding.getAccent();
}

// ---------------------------------------------------------------------
// Tabs
// ---------------------------------------------------------------------

function initTabs() {
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => switchView(btn.dataset.view));
  });
}

function switchView(view) {
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.toggle('active', b.dataset.view === view));
  document.querySelectorAll('.view').forEach(v => v.classList.toggle('active', v.id === `view-${view}`));
  if (view === 'library') refreshLibrary();
}

// ---------------------------------------------------------------------
// Record view
// ---------------------------------------------------------------------

let timerInterval = null;
let lastRecordingBlob = null;
let lastRecordingMime = 'video/webm';

function fmtTimer(ms) {
  const s = Math.floor(ms / 1000);
  const hh = String(Math.floor(s / 3600)).padStart(2, '0');
  const mm = String(Math.floor((s % 3600) / 60)).padStart(2, '0');
  const ss = String(s % 60).padStart(2, '0');
  return `${hh}:${mm}:${ss}`;
}

/** Grabs a single frame (as a small JPEG Blob) to use as a library thumbnail. */
async function captureThumbnail(blob) {
  return new Promise((resolve) => {
    const video = document.createElement('video');
    video.preload = 'metadata';
    video.muted = true;
    video.playsInline = true;
    const cleanup = () => URL.revokeObjectURL(video.src);

    video.onloadedmetadata = () => {
      video.currentTime = Math.min(1, (video.duration || 2) / 4);
    };
    video.onseeked = () => {
      try {
        const canvas = document.createElement('canvas');
        const scale = Math.min(1, 240 / (video.videoWidth || 240));
        canvas.width = (video.videoWidth || 240) * scale;
        canvas.height = (video.videoHeight || 135) * scale;
        canvas.getContext('2d').drawImage(video, 0, 0, canvas.width, canvas.height);
        canvas.toBlob((thumbBlob) => { cleanup(); resolve(thumbBlob); }, 'image/jpeg', 0.7);
      } catch (e) {
        cleanup(); resolve(null);
      }
    };
    video.onerror = () => { cleanup(); resolve(null); };
    video.src = URL.createObjectURL(blob);
  });
}

function initRecordView() {
  if (!Recorder.isSupported()) {
    $('browserSupportNote').textContent =
      "This browser doesn't support screen recording (needs getDisplayMedia + MediaRecorder) — try a recent Chrome, Edge, or Firefox on desktop.";
    $('startBtn').disabled = true;
  } else if (!window.isSecureContext) {
    $('browserSupportNote').textContent =
      'Screen recording requires HTTPS (or localhost) — this page is not currently in a secure context.';
    $('startBtn').disabled = true;
  }

  $('startBtn').addEventListener('click', startRecordingFlow);
  $('pauseBtn').addEventListener('click', togglePause);
  $('stopBtn').addEventListener('click', stopRecordingFlow);
  $('saveLocalBtn').addEventListener('click', downloadLastRecording);
  $('shareRecordBtn').addEventListener('click', shareLastRecording);
  $('saveDriveBtn').addEventListener('click', uploadLastRecordingToDrive);
  $('saveToVaultBtn').addEventListener('click', saveLastRecordingToVault);
}

async function startRecordingFlow() {
  $('status').textContent = 'Choose what to share…';
  try {
    const { mimeType, stopPromise } = await Recorder.prepareRecording({
      quality: $('qualitySelect').value,
      includeMic: $('micCheck').checked,
      includeSystemAudio: $('systemAudioCheck').checked
    });
    lastRecordingMime = mimeType;

    $('qualitySelect').disabled = true;
    $('micCheck').disabled = true;
    $('systemAudioCheck').disabled = true;
    $('recordResult').classList.add('hidden');

    await runCountdown();

    Recorder.beginCapture();
    $('startBtn').classList.add('hidden');
    $('pauseBtn').classList.remove('hidden');
    $('stopBtn').classList.remove('hidden');
    $('pulseRing').classList.add('live');
    $('status').textContent = 'Recording…';

    timerInterval = setInterval(() => { $('timer').textContent = fmtTimer(Recorder.getElapsedMs()); }, 250);

    stopPromise.then(() => { if (Recorder.isRecording()) stopRecordingFlow(); });
  } catch (e) {
    $('qualitySelect').disabled = false;
    $('micCheck').disabled = false;
    $('systemAudioCheck').disabled = false;
    $('status').textContent = e.message || 'Could not start recording.';
  }
}

/** Shows "3… 2… 1…" in the timer display before capture actually begins —
 *  gives you a moment to switch to whatever you meant to record. */
function runCountdown() {
  return new Promise((resolve) => {
    let n = 3;
    $('timer').textContent = String(n);
    $('status').textContent = 'Starting…';
    const tick = setInterval(() => {
      n -= 1;
      if (n > 0) {
        $('timer').textContent = String(n);
      } else {
        clearInterval(tick);
        $('timer').textContent = '00:00:00';
        resolve();
      }
    }, 700);
  });
}

function togglePause() {
  if (Recorder.isPaused()) {
    Recorder.resume();
    $('pauseBtn').textContent = 'Pause';
    $('status').textContent = 'Recording…';
  } else {
    Recorder.pause();
    $('pauseBtn').textContent = 'Resume';
    $('status').textContent = 'Paused';
  }
}

async function stopRecordingFlow() {
  clearInterval(timerInterval);
  $('pulseRing').classList.remove('live');
  $('startBtn').classList.remove('hidden');
  $('pauseBtn').classList.add('hidden');
  $('pauseBtn').textContent = 'Pause';
  $('stopBtn').classList.add('hidden');
  $('qualitySelect').disabled = false;
  $('micCheck').disabled = false;
  $('systemAudioCheck').disabled = false;
  $('status').textContent = 'Finalizing…';

  const blob = await Recorder.stopRecording();
  if (!blob) { $('status').textContent = 'Ready to record'; return; }

  lastRecordingBlob = blob;
  $('status').textContent = 'Ready to record';
  $('recordResult').classList.remove('hidden');
  const mb = (blob.size / (1024 * 1024)).toFixed(1);
  $('recordResultMeta').textContent = `${mb} MB · ${lastRecordingMime.includes('mp4') ? 'MP4' : 'WebM'}`;
  $('recordDriveStatus').textContent = '';

  const previewVideo = $('recordPreviewVideo');
  if (previewVideo.src) URL.revokeObjectURL(previewVideo.src);
  previewVideo.src = URL.createObjectURL(blob);
}

function downloadLastRecording() {
  if (!lastRecordingBlob) return;
  const ext = lastRecordingMime.includes('mp4') ? 'mp4' : 'webm';
  const url = URL.createObjectURL(lastRecordingBlob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `vis-screen-recorder-${Date.now()}.${ext}`;
  a.click();
  URL.revokeObjectURL(url);
}

async function uploadLastRecordingToDrive() {
  if (!lastRecordingBlob) return;
  if (!Drive.hasClientId()) {
    $('recordDriveStatus').textContent = 'Add a Google Client ID in Settings first.';
    return;
  }
  $('recordDriveStatus').textContent = 'Uploading to Google Drive…';
  try {
    const ext = lastRecordingMime.includes('mp4') ? 'mp4' : 'webm';
    const link = await Drive.uploadToDrive(lastRecordingBlob, `vis-screen-recorder-${Date.now()}.${ext}`);
    $('recordDriveStatus').textContent = `Uploaded — ${link}`;
  } catch (e) {
    $('recordDriveStatus').textContent = e.message || 'Upload failed.';
  }
}

/** Shares a recording via the Web Share API where supported (this
 *  requires navigator.canShare({files}) — mainly mobile Chrome and some
 *  recent desktop browsers as of writing). Falls back to a download plus
 *  a clipboard-copied caption on browsers that don't support file
 *  sharing at all, which is most desktop browsers today. */
async function shareBlob(blob, filename) {
  const appName = Branding.getName();
  const caption = `Recorded with ${appName} — free, records offline, encrypted on your device.\n${location.origin}`;

  if (navigator.share) {
    try {
      const file = new File([blob], filename, { type: blob.type || 'video/mp4' });
      if (navigator.canShare && navigator.canShare({ files: [file] })) {
        await navigator.share({ files: [file], title: appName, text: caption });
        return;
      }
    } catch (e) {
      if (e.name === 'AbortError') return; // user cancelled the share sheet — not an error
      console.warn('Web Share failed, falling back to download:', e.message);
    }
  }

  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename; a.click();
  URL.revokeObjectURL(url);

  try {
    await navigator.clipboard.writeText(caption);
    toast('Downloaded — caption copied to your clipboard to paste wherever you share it.', 'info');
  } catch (e) {
    toast('Downloaded — attach it wherever you want to share it.', 'info');
  }
}

async function shareLastRecording() {
  if (!lastRecordingBlob) return;
  const ext = lastRecordingMime.includes('mp4') ? 'mp4' : 'webm';
  await shareBlob(lastRecordingBlob, `vis-screen-recorder-${Date.now()}.${ext}`);
}

async function saveLastRecordingToVault() {
  if (!lastRecordingBlob) return;
  $('recordDriveStatus').textContent = 'Encrypting and saving…';
  try {
    const ext = lastRecordingMime.includes('mp4') ? 'mp4' : 'webm';
    const thumbnailBlob = await captureThumbnail(lastRecordingBlob);
    await Vault.saveRecording(lastRecordingBlob, {
      name: `recording-${Date.now()}.${ext}`, mimeType: lastRecordingMime, thumbnailBlob
    });
    $('recordDriveStatus').textContent = 'Saved to library, encrypted.';
    updateVaultStatus();
  } catch (e) {
    $('recordDriveStatus').textContent = e.message || 'Save failed.';
  }
}

// ---------------------------------------------------------------------
// Shared preview modal (used by Library and AI Clips results)
// ---------------------------------------------------------------------

let previewModalCurrentId = null;
let previewModalOnDelete = null;
let previewModalCurrentBlob = null;

function initPreviewModal() {
  $('previewModalClose').addEventListener('click', closePreviewModal);
  $('previewModal').addEventListener('click', (e) => { if (e.target.id === 'previewModal') closePreviewModal(); });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && !$('previewModal').classList.contains('hidden')) closePreviewModal();
  });
  $('previewModalDownload').addEventListener('click', () => {
    const video = $('previewModalVideo');
    const a = document.createElement('a');
    a.href = video.src;
    a.download = $('previewModalName').textContent || 'recording.mp4';
    a.click();
  });
  $('previewModalShare').addEventListener('click', () => {
    if (previewModalCurrentBlob) shareBlob(previewModalCurrentBlob, $('previewModalName').textContent || 'recording.mp4');
  });
  $('previewModalTrim').addEventListener('click', () => {
    if (previewModalCurrentBlob) openTrimModal(previewModalCurrentBlob, $('previewModalName').textContent || 'recording.mp4');
  });
  $('previewModalDelete').addEventListener('click', async () => {
    if (!previewModalCurrentId) return;
    if (!(await confirmDialog(`Delete "${$('previewModalName').textContent}"? This can't be undone.`))) return;
    await Vault.deleteRecording(previewModalCurrentId);
    closePreviewModal();
    if (previewModalOnDelete) previewModalOnDelete();
  });
}

async function openPreviewModalForEntry(entry, { onDelete } = {}) {
  $('previewModalName').textContent = entry.name;
  const video = $('previewModalVideo');
  if (video.src) URL.revokeObjectURL(video.src);
  video.src = '';
  $('previewModal').classList.remove('hidden');
  previewModalCurrentId = entry.id;
  previewModalOnDelete = onDelete || null;
  previewModalCurrentBlob = null;

  const { blob } = await Vault.loadRecording(entry.id);
  previewModalCurrentBlob = blob;
  video.src = URL.createObjectURL(blob);
}

function closePreviewModal() {
  const video = $('previewModalVideo');
  if (video.src) URL.revokeObjectURL(video.src);
  video.src = '';
  video.pause();
  $('previewModal').classList.add('hidden');
  previewModalCurrentId = null;
  previewModalOnDelete = null;
  previewModalCurrentBlob = null;
}

// ---------------------------------------------------------------------
// Trim modal — manual start/end selection for any recording
// ---------------------------------------------------------------------

let trimSourceBlob = null;
let trimSourceName = null;
let trimDurationSec = 0;

function initTrimModal() {
  const startSlider = $('trimStartSlider');
  const endSlider = $('trimEndSlider');

  function msFor(sliderVal) { return (trimDurationSec * sliderVal) / 1000; }
  function fmt(sec) {
    const s = Math.floor(sec);
    return `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;
  }
  function updateLabel() {
    $('trimRangeLabel').textContent = `${fmt(msFor(+startSlider.value))} — ${fmt(msFor(+endSlider.value))}`;
  }

  [startSlider, endSlider].forEach((slider) => {
    slider.addEventListener('input', () => {
      if (+startSlider.value >= +endSlider.value) {
        if (slider === startSlider) startSlider.value = Math.max(0, +endSlider.value - 10);
        else endSlider.value = Math.min(1000, +startSlider.value + 10);
      }
      updateLabel();
      const previewSec = slider === endSlider ? msFor(+endSlider.value) : msFor(+startSlider.value);
      $('trimModalVideo').currentTime = previewSec;
    });
  });

  $('trimModalClose').addEventListener('click', closeTrimModal);
  $('trimCancelBtn').addEventListener('click', closeTrimModal);
  $('trimModal').addEventListener('click', (e) => { if (e.target.id === 'trimModal') closeTrimModal(); });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && !$('trimModal').classList.contains('hidden')) closeTrimModal();
  });

  $('trimSaveBtn').addEventListener('click', async () => {
    const startSec = msFor(+startSlider.value);
    const endSec = msFor(+endSlider.value);
    if (endSec - startSec < 0.5) { toast('Selection is too short.', 'error'); return; }

    $('trimProgress').classList.remove('hidden');
    $('trimSaveBtn').disabled = true;
    try {
      const trimmedBlob = await Ffmpeg.trimVideo(trimSourceBlob, startSec, endSec, {
        onProgress: (p) => { $('trimProgress').querySelector('.progress-bar').style.width = `${p}%`; }
      });
      const thumbnailBlob = await captureThumbnail(trimmedBlob);
      const newName = `trimmed-${trimSourceName}`;
      await Vault.saveRecording(trimmedBlob, { name: newName, mimeType: 'video/mp4', thumbnailBlob });
      toast('Trimmed copy saved to your library, encrypted.', 'success');
      closeTrimModal();
      refreshLibrary();
    } catch (e) {
      toast(e.message || 'Trim failed.', 'error');
    } finally {
      $('trimProgress').classList.add('hidden');
      $('trimSaveBtn').disabled = false;
    }
  });

}

async function openTrimModal(blob, name) {
  trimSourceBlob = blob;
  trimSourceName = name;
  closePreviewModal();

  const video = $('trimModalVideo');
  if (video.src) URL.revokeObjectURL(video.src);
  video.src = URL.createObjectURL(blob);
  $('trimStartSlider').value = 0;
  $('trimEndSlider').value = 1000;
  $('trimModal').classList.remove('hidden');

  trimDurationSec = await getVideoDuration(blob);
  $('trimRangeLabel').textContent = `00:00 — ${Math.floor(trimDurationSec / 60)}:${String(Math.floor(trimDurationSec % 60)).padStart(2, '0')}`;
}

function closeTrimModal() {
  const video = $('trimModalVideo');
  if (video.src) URL.revokeObjectURL(video.src);
  video.src = '';
  video.pause();
  $('trimModal').classList.add('hidden');
  trimSourceBlob = null;
}

function thumbHtml(entry) {
  if (entry.thumbnailUrl) return `<img class="entry-thumb" src="${entry.thumbnailUrl}" alt="" />`;
  return `<div class="entry-thumb"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 6h16v12H4z"/><path d="M9 9l6 3-6 3V9z" fill="currentColor" stroke="none"/></svg></div>`;
}

// ---------------------------------------------------------------------
// Library view
// ---------------------------------------------------------------------

let libraryPickCallback = null;

function initLibraryView() {
  initPreviewModal();
  initTrimModal();
}

async function refreshLibrary() {
  const entries = await Vault.listRecordings();
  const list = $('libraryList');
  list.innerHTML = '';
  $('libraryEmpty').classList.toggle('hidden', entries.length > 0);

  const totalMb = entries.reduce((s, e) => s + (e.sizeBytes || 0), 0) / (1024 * 1024);
  $('librarySummary').textContent = `${entries.length} recording${entries.length === 1 ? '' : 's'} · ${totalMb.toFixed(1)} MB encrypted`;

  for (const entry of entries) {
    const row = document.createElement('div');
    row.className = 'entry-row';
    const sizeMb = (entry.sizeBytes / (1024 * 1024)).toFixed(1);
    const date = new Date(entry.createdAt).toLocaleString();
    row.innerHTML = `
      ${thumbHtml(entry)}
      <div class="entry-info">
        <p class="entry-name">${escapeHtml(entry.name)}</p>
        <p class="entry-meta">${sizeMb} MB · ${date} · encrypted</p>
      </div>
      <div class="entry-actions">
        <button data-action="delete" title="Delete">&#128465;</button>
      </div>`;

    row.addEventListener('click', async (e) => {
      const action = e.target.closest('button')?.dataset.action;
      if (action === 'delete') {
        e.stopPropagation();
        if (await confirmDialog(`Delete "${entry.name}"? This can't be undone.`)) {
          await Vault.deleteRecording(entry.id);
          refreshLibrary();
        }
      } else if (libraryPickCallback) {
        libraryPickCallback(entry);
      } else {
        openPreviewModalForEntry(entry, { onDelete: refreshLibrary });
      }
    });

    list.appendChild(row);
  }
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

async function updateVaultStatus() {
  const entries = await Vault.listRecordings();
  const totalMb = entries.reduce((s, e) => s + (e.sizeBytes || 0), 0) / (1024 * 1024);
  $('vaultStatusText').textContent = `${entries.length} recordings, ${totalMb.toFixed(1)} MB, AES-256 encrypted in this browser's storage.`;
}

// ---------------------------------------------------------------------
// AI Clips view
// ---------------------------------------------------------------------

let clipsSourceBlob = null;
let clipsSoundtrackBlob = null;

function initClipsView() {
  const themeSelect = $('clipsThemeSelect');
  AiClips.THEMES.forEach(t => {
    const opt = document.createElement('option');
    opt.value = t.id; opt.textContent = t.label;
    themeSelect.appendChild(opt);
  });

  $('clipsAiSettingsBtn').addEventListener('click', () => $('aiSettingsModal').classList.remove('hidden'));

  $('clipsFromLibraryBtn').addEventListener('click', () => {
    switchView('library');
    $('clipsSourceStatus').textContent = 'Tap a recording in your library to use it…';
    libraryPickCallback = async (entry) => {
      libraryPickCallback = null;
      switchView('clips');
      $('clipsSourceStatus').textContent = `Decrypting "${entry.name}"…`;
      const { blob } = await Vault.loadRecording(entry.id);
      clipsSourceBlob = blob;
      $('clipsSourceStatus').textContent = `Source: ${entry.name} (from your library)`;
    };
  });

  $('clipsImportFileBtn').addEventListener('click', () => $('clipsFileInput').click());
  $('clipsFileInput').addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (!file) return;
    clipsSourceBlob = file;
    $('clipsSourceStatus').textContent = `Source: ${file.name} (imported)`;
  });

  $('clipsImportLinkBtn').addEventListener('click', async () => {
    const url = $('clipsLinkInput').value.trim();
    if (!url) { $('clipsSourceStatus').textContent = 'Paste a direct video link first.'; return; }
    $('clipsSourceStatus').textContent = 'Downloading…';
    try {
      const response = await fetch(url);
      if (!response.ok) throw new Error(`Couldn't fetch that link (${response.status}).`);
      const contentType = response.headers.get('Content-Type') || '';
      if (!contentType.startsWith('video/') && !url.split('?')[0].endsWith('.mp4')) {
        throw new Error("That link doesn't point to a direct video file. This only works with direct-download links you have rights to — not YouTube/TikTok page URLs, which this app won't attempt to rip.");
      }
      clipsSourceBlob = await response.blob();
      $('clipsSourceStatus').textContent = 'Source: downloaded from link.';
    } catch (e) {
      $('clipsSourceStatus').textContent = e.message || 'Import failed.';
    }
  });

  $('clipsSoundtrackCheck').addEventListener('change', (e) => {
    $('clipsPickSoundtrackBtn').classList.toggle('hidden', !e.target.checked);
    if (!e.target.checked) clipsSoundtrackBlob = null;
  });
  $('clipsPickSoundtrackBtn').addEventListener('click', () => $('clipsSoundtrackInput').click());
  $('clipsSoundtrackInput').addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (file) { clipsSoundtrackBlob = file; $('clipsPickSoundtrackBtn').textContent = `\u2713 ${file.name}`; }
  });

  $('clipsGenerateBtn').addEventListener('click', generateClips);

  refreshClipsAiStatus();
}

function refreshClipsAiStatus() {
  $('clipsAiStatus').textContent = AiSettings.isConfigured()
    ? `Using ${AiSettings.PROVIDERS[AiSettings.getProvider()].label} — clip picks and captions are AI-generated.`
    : 'No AI provider configured — clips will be evenly spaced instead of AI-picked.';
}

function setClipsProgress(percent) {
  const bar = $('clipsProgress');
  bar.classList.toggle('hidden', percent === null);
  if (percent !== null) bar.querySelector('.progress-bar').style.width = `${percent}%`;
}

async function getVideoDuration(blob) {
  return new Promise((resolve) => {
    const video = document.createElement('video');
    video.preload = 'metadata';
    video.onloadedmetadata = () => { resolve(video.duration); URL.revokeObjectURL(video.src); };
    video.onerror = () => resolve(0);
    video.src = URL.createObjectURL(blob);
  });
}

async function generateClips() {
  if (!clipsSourceBlob) { $('clipsStatus').textContent = 'Pick a source video first.'; return; }

  const themeId = $('clipsThemeSelect').value;
  const theme = AiClips.THEMES.find(t => t.id === themeId);
  const clipCount = parseInt($('clipsCountSelect').value, 10) || 5;

  $('clipsGenerateBtn').disabled = true;
  $('clipsResults').innerHTML = '';
  setClipsProgress(0);

  try {
    const durationSec = await getVideoDuration(clipsSourceBlob);
    if (!durationSec) throw new Error("Couldn't read this video's duration.");

    let transcript = [];
    if (AiSettings.isConfigured() && AiSettings.providerSupportsWhisper()) {
      $('clipsStatus').textContent = 'Extracting audio for transcription…';
      const audioBlob = await Ffmpeg.extractAudio(clipsSourceBlob, { onProgress: setClipsProgress });
      $('clipsStatus').textContent = 'Transcribing…';
      try {
        transcript = await AiClips.transcribe(audioBlob);
      } catch (e) {
        $('clipsStatus').textContent = `Transcription skipped: ${e.message}`;
      }
    }

    $('clipsStatus').textContent = AiSettings.isConfigured() ? 'Asking AI for the best moments…' : 'Splitting into evenly-spaced clips (no AI configured)…';
    const suggestions = await AiClips.suggestClips({ theme, transcript, durationSec, clipCount });

    if (suggestions.length === 0) {
      $('clipsStatus').textContent = "Couldn't find any clip-worthy moments — try a longer recording.";
      return;
    }

    for (let i = 0; i < suggestions.length; i++) {
      const s = suggestions[i];
      $('clipsStatus').textContent = `Cutting clip ${i + 1} of ${suggestions.length}…`;
      let clipBlob = await Ffmpeg.trimVideo(clipsSourceBlob, s.start, s.end, { onProgress: setClipsProgress });

      if (clipsSoundtrackBlob) {
        $('clipsStatus').textContent = `Adding soundtrack to clip ${i + 1}…`;
        clipBlob = await Ffmpeg.applySoundtrack(clipBlob, clipsSoundtrackBlob, { onProgress: setClipsProgress });
      }

      const safeName = (s.title || `${theme.label} Clip ${i + 1}`).replace(/[^A-Za-z0-9 _-]/g, '').slice(0, 60);
      const thumbnailBlob = await captureThumbnail(clipBlob);
      const vaultId = await Vault.saveRecording(clipBlob, {
        name: `${safeName}.mp4`, mimeType: 'video/mp4', theme: theme.id, caption: s.caption, thumbnailBlob
      });

      const row = document.createElement('div');
      row.className = 'entry-row';
      const thumbUrl = thumbnailBlob ? URL.createObjectURL(thumbnailBlob) : null;
      row.innerHTML = `
        ${thumbUrl ? `<img class="entry-thumb" src="${thumbUrl}" alt="" />` : '<div class="entry-thumb"></div>'}
        <div class="entry-info">
          <p class="entry-name" style="color:${theme.accent}">${escapeHtml(safeName)}</p>
          <p class="entry-meta">${escapeHtml(s.caption || '')}</p>
        </div>`;
      row.addEventListener('click', () => {
        openPreviewModalForEntry({ id: vaultId, name: `${safeName}.mp4` }, { onDelete: () => row.remove() });
      });
      $('clipsResults').appendChild(row);
    }

    $('clipsStatus').textContent = `Done — ${suggestions.length} clips saved to your library, encrypted.`;
    clipsSourceBlob = null;
    $('clipsSourceStatus').textContent = 'No source selected yet.';
  } catch (e) {
    $('clipsStatus').textContent = e.message || 'Something went wrong generating clips.';
  } finally {
    setClipsProgress(null);
    $('clipsGenerateBtn').disabled = false;
  }
}

// ---------------------------------------------------------------------
// Settings view
// ---------------------------------------------------------------------

let pendingLogoDataUrl = null;

function initSettingsView() {
  $('brandNameInput').value = Branding.getName();
  $('brandAccentInput').value = Branding.getAccent();
  $('googleClientIdInput').value = localStorage.getItem('vis_google_client_id') || '';

  $('brandLogoInput').addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => { pendingLogoDataUrl = reader.result; };
    reader.readAsDataURL(file);
  });

  $('saveBrandingBtn').addEventListener('click', () => {
    Branding.save({
      name: $('brandNameInput').value.trim() || 'Vis Screen Recorder',
      accent: $('brandAccentInput').value,
      logoDataUrl: pendingLogoDataUrl
    });
    applyBranding();
    toast('Branding saved.', 'success');
  });

  $('saveGoogleClientBtn').addEventListener('click', () => {
    Drive.setClientId($('googleClientIdInput').value.trim());
    toast('Google Client ID saved.', 'success');
  });
}

// ---------------------------------------------------------------------
// AI settings modal
// ---------------------------------------------------------------------

function initAiSettingsModal() {
  const providerSelect = $('aiProviderSelect');
  Object.entries(AiSettings.PROVIDERS).forEach(([key, p]) => {
    const opt = document.createElement('option');
    opt.value = key; opt.textContent = p.label;
    providerSelect.appendChild(opt);
  });
  providerSelect.value = AiSettings.getProvider();
  $('aiApiKeyInput').value = AiSettings.getApiKey();

  $('aiSettingsSaveBtn').addEventListener('click', () => {
    const apiKey = $('aiApiKeyInput').value.trim();
    if (!apiKey) { toast('Enter an API key first.', 'error'); return; }
    AiSettings.save({
      provider: providerSelect.value,
      apiKey,
      baseUrl: $('aiBaseUrlInput').value.trim(),
      model: $('aiModelInput').value.trim()
    });
    $('aiSettingsModal').classList.add('hidden');
    refreshClipsAiStatus();
    toast('AI provider settings saved.', 'success');
  });

  $('aiSettingsCloseBtn').addEventListener('click', () => $('aiSettingsModal').classList.add('hidden'));
  $('aiSettingsModal').addEventListener('click', (e) => { if (e.target.id === 'aiSettingsModal') $('aiSettingsModal').classList.add('hidden'); });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && !$('aiSettingsModal').classList.contains('hidden')) $('aiSettingsModal').classList.add('hidden');
  });
}

// ---------------------------------------------------------------------
// Global error resilience — surfaces anything unhandled as a toast
// instead of it silently vanishing into the console where only a
// developer would ever see it.
// ---------------------------------------------------------------------

window.addEventListener('error', (e) => {
  console.error('Unhandled error:', e.error || e.message);
  toast('Something went wrong — check the console for details.', 'error');
});

window.addEventListener('unhandledrejection', (e) => {
  console.error('Unhandled promise rejection:', e.reason);
  toast((e.reason && e.reason.message) || 'Something went wrong — check the console for details.', 'error');
});

// ---------------------------------------------------------------------
// Service worker — app-shell caching for instant repeat loads and
// PWA installability. Registration failure is non-fatal; the app works
// identically without it, just without the offline-shell/install perk.
// ---------------------------------------------------------------------

if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./sw.js').catch((e) => {
      console.warn('Service worker registration failed (non-fatal):', e.message);
    });
  });
}

// ---------------------------------------------------------------------
initUnlockGate();
