// sw.js — caches the app shell (HTML/CSS/JS/icons) for instant repeat
// loads and PWA installability. Deliberately does NOT cache anything
// from unpkg.com (ffmpeg.wasm) — that's versioned by URL already, and
// caching it here risks silently pinning a stale build across app
// updates. The browser's own HTTP cache handles that fine on its own.

const CACHE_NAME = 'vis-screen-recorder-shell-v1';
const SHELL_FILES = [
  './',
  './index.html',
  './css/styles.css',
  './js/main.js',
  './js/crypto.js',
  './js/vault.js',
  './js/recorder.js',
  './js/ffmpegClient.js',
  './js/drive.js',
  './js/aiSettings.js',
  './js/aiClips.js',
  './js/branding.js',
  './js/toast.js',
  './manifest.json',
  './icons/favicon-32.png',
  './icons/apple-touch-icon.png',
  './icons/icon-512.png'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(SHELL_FILES))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((names) =>
      Promise.all(names.filter((n) => n !== CACHE_NAME).map((n) => caches.delete(n)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);

  // Only handle same-origin GET requests — everything else (the ffmpeg
  // CDN, the OpenAI/NVIDIA API calls, Google's OAuth endpoints) passes
  // straight through untouched.
  if (event.request.method !== 'GET' || url.origin !== self.location.origin) return;

  event.respondWith(
    caches.match(event.request).then((cached) => {
      if (cached) return cached;
      return fetch(event.request).then((response) => {
        if (response.ok) {
          const clone = response.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(event.request, clone));
        }
        return response;
      }).catch(() => cached); // offline and not cached — nothing we can do
    })
  );
});
